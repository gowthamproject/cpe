package com.wipro.cpe.common;

public class Core5GDetails {

    public static final String _5G_CORE_ID = "22223343343";
    public static final String SYSTEM_NAME = "5G Def-i Innovation Center";
    public static final String _5G_CORE = "CPE";
    public static final String VENDOR = "CPE";
}
  